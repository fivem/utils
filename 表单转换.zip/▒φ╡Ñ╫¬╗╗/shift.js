function shift(){
	var begin = '<!DOCTYPE html>                                                                                                                                                  '
				+'<html>                                                                                                                                                          '
				+'	<head>                                                                                                                                                        '
				+'<meta name="renderer" content="webkit">                                                                                                                         '
				+'<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />                                                                                                '
				+'		<title>测试表单样式</title>                                                                                                                               '
				+'		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>                                                                                      '
				+'		<meta name="renderer" content="webkit">                                                                                                                   '
				+'		<meta name="apple-mobile-web-app-capable" content="yes">                                                                                                  '
				+'		<meta name="apple-mobile-web-app-status-bar-style" content="black">                                                                                       '
				+'		[#AWSImport]                                                                                                                                              '
				+'		[#AWSUIImport]                                                                                                                                            '
				+'		<link rel="stylesheet" id="schemeCss" href="../apps/_bpm.platform/css/colorschemes/scheme_aws.css"  name="schemeCss"/>                                    '
				+'	                                                                                                                                                              '
				+'<link type="text/css" rel="stylesheet" id="themeCss" href="../apps/_bpm.platform/css/theme/theme.css" name="themeCss"/>                                         '
				+'</head>                                                                                                                                                         '
				+'	<body>                                                                                                                                                        '
				+'<form id="frmMain" name="frmMain" method="post">                                                                                                                '
				+'<div id="aws-form-container" class="aws-form-ux-container" border="0">                                                                                          '
				+'<table id="aws-form-maintable" class="awsui-ux aws-form-ux-maintable" style="table-layout: auto;" align="center" border="0" cellpadding="0" cellspacing="0">    '
				+'<tbody>                                                                                                                                                         '
				+'<tr class="aws-form-ux-formcontent" id="aws-form-formcontent">                                                                                                  '
				+'<td>                                                                                                                                                            ';


	var end = 	'</td>                                                 '
				+'</tr>                                                '
				+'<tr class="aws-form-bottom">                         '
				+'<td class="aws-form-ux-actionsoft">[#Actionsoft]</td>'
				+'</tr>                                                '
				+'</tbody>                                             '
				+'</table>                                             '
				+'</div>                                               '
				+'</form>                                              '
				+'</body>                                              '
				+'</html>                                              ';
				
				
	var origin = $("#origin").val();
	$("#hidden").html(origin);
	
	var tableHtml = $(".zw_formdata");
	$("#hidden").html(tableHtml);
	//process table
	for(var i=0;i<tableHtml.length;i++){
		//process sub_table
		if($(tableHtml[i]).attr("path")!==undefined){
			$(tableHtml[i]).after('<div class="aws-form-ux-grid" border="0">[#Grid1]</div>');
			$(tableHtml[i]).remove();
			continue;
		}
		var tr = $(tableHtml[i]).find("tr");
		//process tr
		for(var j=0;j<tr.length;j++){
			var td=$(tr[j]).find("td");
			//process td
			for(var k=0;k<td.length;k++){
				$(td[k]).removeAttr("ng-if");
				$(td[k]).removeAttr("class");
				
				//find ng-model
				var ngModel = $(td[k]).find("[ng-model]");
				var ngModelStr = $(ngModel[0]).attr("ng-model");
				if(ngModelStr ===undefined){
					continue;
				}
				var ngModelAttr = ngModelStr.split(".");
				var ele = ngModelAttr[ngModelAttr.length-1];
				$(ngModel[0]).after("[#"+ele.toUpperCase()+"]");
				//if parent contains ng-repeat
				if($(ngModel[0]).parent().attr("ng-repeat")!==undefined){
					$(ngModel[0]).parent().remove();
				}else{
					$(ngModel[0]).remove();	
				}
				
				//remove time_sap
				var time_sap = $(td[k]).find(".table_form_time_sap");
				time_sap.next().remove();
				time_sap.remove();
				
			}
		}
	}
	
	$("#target").val(begin+$("#hidden").html()+end);
}


